﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.IO;

//namespace student
//{
//    class file
//    {
//        public void delete_rec(string Key, string entry, string path)
//        {
//            string tempFile = Path.GetTempFileName();
//            using (var sr = new StreamReader(path)) 
//            using (var sw = new StreamWriter(tempFile))
//            {
//                string line;

//                while ((line = sr.ReadLine()) != null)
//                {
//                    if (line != "removeme")
//                        sw.WriteLine(line);
//                }
//            }
//            File.Delete("D:/file.txt");
//            File.Move(tempFile, "file.txt");
//        }
//    }
//}

