﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace student
{
    class attendence
    {
        private List<string> nameList = new List<string>();
        public void attend(string Key, string path)
        {
            
            using (StreamReader file = new StreamReader(path))
            {
                string flag;



                while ((flag = file.ReadLine()) != null)
                {


                    if (Key == flag.Substring(0, 4))
                    {
                        nameList.Add(flag.Substring(4));

                    }

                }

               
            }
        }

        public void attend_conc(string present="A")
        {
            for(int i=0;i<=nameList.Count;i++)
            {
                nameList[i] = nameList + "-" + present;
            }
        }

        public void show_Attendence()
        {
            for (int i = 0; i <= nameList.Count; i++)
            {
                Console.WriteLine(nameList[i]);
            }
        }
    }

}
